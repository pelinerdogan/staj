package com.nevitech.allianz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AllianzApplication {

	public static void main(String[] args) {
		SpringApplication.run(AllianzApplication.class, args);
	}

}
